// File: math_operations.cpp
#include "math_operations.h"

// Function definitions
int add(int a, int b) {
    return a + b;
}

int subtract(int a, int b) {
    return a - b;
}

// Variable definition
int globalValue = 10;
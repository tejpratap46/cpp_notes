// File: math_operations.h
#ifndef MATH_OPERATIONS_H
#define MATH_OPERATIONS_H

// Function declarations
int add(int a, int b);
int subtract(int a, int b);

// Variable declaration with external linkage
extern int globalValue;

#endif // MATH_OPERATIONS_H
// File: main.cpp
#include <iostream>
#include "math_operations.h"

int main() {
    std::cout << "Sum: " << add(5, 3) << std::endl;
    std::cout << "Difference: " << subtract(10, 4) << std::endl;
    std::cout << "Global value: " << globalValue << std::endl;
    return 0;
}